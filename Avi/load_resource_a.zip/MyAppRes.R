// MYAPPAVI AVI MYAPP.AVI
// [resource name] [Resource Type] [Resource File]
MyAppAvi AVI MyApp.avi
MyAppBmp BITMAP Smily01.bmp
MyAppTxt TXT Abaut.txt
MyAppDisclaim DisclaimText Disclaim.txt

