

Contact Me
----------
Ulukaya, Tayfun
EMail: tayfunulukaya@yahoo.com
WWW: www.geocities.com/tayfunulukaya


Abaut
----------
Borland Delphi Sample application including
step-by-step description of the useage of a variety of 
resource types, see "Step.txt" for an extended 
useage


Notice
----------
Source can be freely distributed &/or modified

I highly appreciate if you refer to the author
when the source is distributed &/or used by any means

all the comments, suggestions, corrections are welcome


Disclaimer
----------
The author hereby disclaims all warranties relating to this software,
whether express or implied, including without limitation any implied
warranties of merchantability or fitness for a particular purpose.
The author will not be liable for any special, incidental, consequential,
indirect or similar damages due to loss of data or any other reason,
even if advised of the possibility of such damages. Use of this software
constitutes agreement to these terms by the licensee.



  Delphi is a Trademark of Borland/Inprise International
